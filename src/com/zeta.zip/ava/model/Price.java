package com.ava.model;

public class Price {
    int basePrice;
    VechicleType vechicleType;
}
