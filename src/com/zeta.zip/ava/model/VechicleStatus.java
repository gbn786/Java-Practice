package com.ava.model;

public enum VechicleStatus {
    //Booked, Free, Deactivated, Available
    AVAILABLE, BOOKED, BLOCKED, REMOVED;
}
