package com.ava.model;

public enum UserStatus {
    APPROVED, NOT_APPROVED, BLOCKED;
}
