package com.ava.model;

public enum BookingStatus {
}
