package com.ava.model;

import java.util.Date;

public class UserBookInfo {
    int userId;
    int vechicleId;
    Date startdate;
    Date returnDate;
    Date expectedRetrunDate;
    BookingStatus bookingStatus;// Return

}
