package com.ava.model;

public enum PriceType {
    WEEKEND, FESTIVE;
}
