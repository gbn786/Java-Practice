package com.ava.model;

public enum VechicleType {
    ////HatchBag, Sedan, SUV
    HATCHBAG, SEDAN, SUV, LUXURY;
}
