package com.ava.serviceImpl;

import com.ava.model.DynamicPrice;
import com.ava.model.Vechicle;

public class PriceCalculator {

    public int getPrice(Vechicle vechicle) {
        //
        int finalPrice = 0;

        //get the base price for the vechicle

        // check if dynamicPrice is enable and calucute the final
        //DynamicPrice dynamicPrice;
        dynamicPrice.getBasePrice *


        return finalPrice;
    }
}
